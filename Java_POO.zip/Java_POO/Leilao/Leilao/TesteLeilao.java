package PC2.aula3;

import PC2.aula3.classes.Lance;
import PC2.aula3.classes.Leilao;
import PC2.aula3.classes.Lote;
import PC2.aula3.classes.Pessoa;
import PC2.aula3.classes.Produto;

//import java.util.Scanner;

public class TesteLeilao {
    public static void main (String args[]){
        Pessoa pessoal = new Pessoa("LEILAO", "000");
        Pessoa pessoa1 = new Pessoa("joao", "3199887766");
        Pessoa pessoa2 = new Pessoa("lucas","3144335566");

        Lance lance = new Lance(pessoal, 20);
        Lance lance1 = new Lance(pessoa1, 50);
        Lance lance2 = new Lance(pessoa2, 100);

        Produto produto = new Produto("carro", lance);

        Lote lote = new Lote();
        lote.inserirProduto(produto);

        Leilao leilao = new Leilao();
        leilao.inserirLote(lote);
        leilao.receberLance(0, produto.getDescricao(), lance);
        leilao.receberLance(0, produto.getDescricao(), lance1);
        leilao.receberLance(0, produto.getDescricao(), lance2);

        
        leilao.listarProdutos();
        
        leilao.encerrarLeilao();    

    }
}
