package PC2.aula3.classes;
//import PC2.aula3.classes.Produto;

import java.util.ArrayList;

public class Leilao {
    private ArrayList<Lote> lotes = new ArrayList<Lote>();

    public ArrayList<Lote> getLotes() {
        return lotes;
    }

    public void setLotes(ArrayList<Lote> lotes) {
        this.lotes = lotes;
    }

    public void inserirLote(Lote lote) {
        this.lotes.add(lote);
    }

    public void receberLance(int plote, String descricaop, Lance lance) {

        ArrayList<Produto> propos = lotes.get(plote).getProdutos();

        for (int i = 0; i < propos.size(); i++) {
            if (propos.get(i).getDescricao().equals(descricaop)) {
                propos.get(i).verificarMaiorLance(lance);
            }
        }

    }

    public void encerrarLeilao(){
        for(int i=0;i<lotes.size();i++){
            ArrayList<Produto> propos = lotes.get(i).getProdutos(); 
            for(int j=0;j<propos.size();j++){
                System.out.println(propos.get(j).getDescricao() + "\n" + propos.get(j).getMaiorLance().getValor() + "\n" + propos.get(j).getMaiorLance().getPessoa().getNome());
            }
        }
    }   

    public void listarProdutos() {
        for(int i=0;i<lotes.size();i++){
            ArrayList<Produto> propos = lotes.get(i).getProdutos();
                for(int j=0;j<lotes.size();j++){
                    System.out.println(propos.get(j).getDescricao() + "\n" + propos.get(j).getMaiorLance().getValor());
                } 
          }
    }    

    

}
