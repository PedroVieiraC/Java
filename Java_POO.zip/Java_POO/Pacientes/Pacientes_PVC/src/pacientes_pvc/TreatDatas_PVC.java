package pacientes_pvc;

import java.util.ArrayList;
import pacientes_pvc.Pessoa_PVC;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Marcela
 */
public class TreatDatas_PVC {

     ArrayList<Pessoa_PVC> pessoas = new ArrayList<>();

    
    public TreatDatas_PVC(ArrayList<Pessoa_PVC> pessoas) {
        this.pessoas = pessoas;
    }

    public ArrayList<Pessoa_PVC> getPessoas() {
        return pessoas;
    }

    public void setPessoas(ArrayList<Pessoa_PVC> pessoas) {
        this.pessoas = pessoas;
    }

    public int qtdPacientes() {
        return pessoas.size();
    }

    public float miHomens() {
        int mihm = 0;
        int qtdHm=0;
        for (Pessoa_PVC aux : pessoas) {
            if (aux.getGenero().equals("masculino")) {
                mihm += aux.getIdade();
                qtdHm++;
            }
        }
        return mihm/qtdHm;
    }

    public int mulheresParametros() {
        int qtd = 0;
        for (Pessoa_PVC aux : pessoas) {
            if (aux.getGenero().equals("feminino")) {
                if (aux.getAltura() >= 1.60 && aux.getAltura() <= 1.70) {
                    if (aux.getPeso() > 70)
                        qtd++;
                }
            }
        }
        return qtd;

    }

    public int pessoasAcima25() {
        int qtd = 0;
        for (Pessoa_PVC aux : pessoas) {
            if (aux.getIdade() > 18 && aux.getIdade() < 25)
                qtd++;
        }
        return qtd;
    }

    public String nomeMaisVelho() {
        String nome = new String();
        int idaux = 0;
        for (Pessoa_PVC aux : pessoas) {
            if (aux.getIdade() > idaux) {
                nome = aux.getNome();
                idaux = aux.getIdade();
            }
        }
        return nome;
    }

    public String nomeMaisBaixa() {
        String nome = new String();
        int altaux = 5;
        for (Pessoa_PVC aux : pessoas) {
            if (aux.getGenero().equals("feminino")) {
                if (aux.getAltura() < altaux) {
                    nome = aux.getNome();
                    altaux = aux.getIdade();
                }
            }
        }
        return nome;
    }

}


