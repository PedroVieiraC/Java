Olá! Me chamo Pedro Vieira, e nessa pasta deixarei todos os meus códigos relacionados ao aprendizado de programação
orientada a objetos em java;

os códigos foram orientados pela professora Luciana Campos, do cefet mg;

