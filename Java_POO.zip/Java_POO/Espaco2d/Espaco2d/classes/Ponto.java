package PC2.Espaco.classes;
import java.lang.Math;

public class Ponto{
    private double x;
    private double y;
    
    public double getX() {
        return x;
    }
    public void setX(double x) {
        this.x = x;
    }
    public double getY() {
        return y;
    }
    public void setY(double y) {
        this.y = y;
    }
    
    /*public Ponto(){
        this.x=0;
        this.y=0;
    }*/
    
    public Ponto(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    public Ponto(Ponto ponto){
        this.x = ponto.getX();
        this.y = ponto.getY();
    }
    
    public double calculaDistancia(Ponto ponto){
        return Math.sqrt(Math.pow((ponto.getX() -this.x), 2) + Math.pow((ponto.getY() - this.y),2));
    }

}