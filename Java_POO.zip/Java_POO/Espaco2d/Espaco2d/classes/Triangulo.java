package PC2.Espaco.classes;

import java.lang.Math;

public class Triangulo extends Forma {
    private double a, b, c;

    public Triangulo(double a, double b, double c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }



    public String tipoTriangulo() {
        if ((a == b) && (b == c)) {
            return "equilatero";
        }
        if ((a == b && b != c) || (a == c && c != b) || (b == c && c != a)) {
            return "isosceles";
        }
        return "escaleno";
    }

    @Override
    public double calculaArea() {
        double area=0;
        if (tipoTriangulo().equals("equilatero")) {
            area = (Math.pow(a, 2) * Math.sqrt(3)) / 4;
            return area;
        }
        if (tipoTriangulo().equals("isosceles")) {
            if (a == b)
                return area = (a * c) / 2;
            if (a == c)
                return area = (a * b) / 2;
            if (b == c)
                return area = (b * a) / 2;
        }

        if (tipoTriangulo().equals("escaleno")) {
            double p = (a + b + c) / 2;
            area = Math.sqrt((p * (p - a)) + (p * (p - b)) + (p * (p - c)));
            return area;
        }
        return area;

    }

    @Override
    public double calculaPerimetro() {
        return a + b + c;
    }

}
