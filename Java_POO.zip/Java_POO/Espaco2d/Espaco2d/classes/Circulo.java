package PC2.Espaco.classes;
import java.lang.Math;

public class Circulo extends Forma {
    private double a;

    public Circulo(double a) {
        super();
        this.a = a;
    }
    
    public double getA() {
        return a;
    }
    public void setA(double a) {
        this.a = a;
    }


    @Override
    public double calculaArea() {
        return Math.PI*(Math.pow(a,2));
    }

    @Override
    public double calculaPerimetro() {
        return Math.PI*(2*a);
    }





}
