package PC2.Espaco.classes;

public abstract class Forma {
    private Ponto[] pontos;

    public abstract double calculaArea();

    public abstract double calculaPerimetro();

    public static Forma geraForma(Ponto[] pontos) {
        int tamanho = pontos.length;
        Forma forma;
        if (tamanho == 2) {
            double a = pontos[0].calculaDistancia(pontos[1]);
            if (a != 0) {
                return forma = new Circulo(a);
            }
        }

        if (tamanho == 3) {
            double a = pontos[0].calculaDistancia(pontos[1]);
            double b = pontos[1].calculaDistancia(pontos[2]);
            double c = pontos[2].calculaDistancia(pontos[0]);
            if (a + b > c && b + c > a && c + a > b) {
                return forma = new Triangulo(a, b, c);
            }

        }
        if (tamanho == 4) {
            double a = pontos[0].calculaDistancia(pontos[1]);
            double b = pontos[1].calculaDistancia(pontos[2]);
            double c = pontos[2].calculaDistancia(pontos[3]);
            double d = pontos[3].calculaDistancia(pontos[0]);
            if ((a == b && b == c && c == d) && a != 0) {
                return forma = new Quadrado(a, b, c, d);
            }

        }

        return null;
    }

}
