package classes;

public class AssalariadoComi extends Comissionado {
    private double percentualBonus;
    
    public void setPercentualBonus(double percentualBonus) {
        this.percentualBonus = percentualBonus;
    }
    public double getPercentualBonus() {
        return percentualBonus;
    }
    public double getValorVendas() {
        return valorVendas;
    }
    public void setValorVendas(double valorVendas) {
        this.valorVendas = valorVendas;
    }

    public AssalariadoComi(String nome, String sobrenome, int numIdent, double valorVendas, double percentualBonus) {
        super(nome, sobrenome, numIdent, valorVendas);
        this.percentualBonus = percentualBonus;
    }

    public double getValorAPagar(int diaPagto, int mesPagto){
        return Passivo.SALARIO + (valorVendas*0.06) + percentualBonus;
    }

   
    
}
