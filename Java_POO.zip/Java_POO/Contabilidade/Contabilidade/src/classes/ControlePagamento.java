package classes;

import java.util.ArrayList;

public class ControlePagamento {
    private ArrayList<Passivo> pagamentos;

    public ArrayList<Passivo> getPagamentos() {
        return pagamentos;
    }

    public void setPagamentos(ArrayList<Passivo> pagamentos) {
        this.pagamentos = pagamentos;
    }

    public ControlePagamento() {
        this.pagamentos = new ArrayList<Passivo>();
    }

    public void addPagamentos(Passivo pag) {
        this.pagamentos.add(pag);
    }

    public double vpEmpregados() {
        double custo = 0;
        for (Passivo emp : pagamentos) {
            if (emp instanceof Empregado) {
                custo += emp.getValorAPagar(0, 0);
            }
        }
        return custo;

    }

    public double vpContas(int diaPagto, int mesPagto) {
        double custo = 0;
        for (Passivo cont : pagamentos) {
            if (cont instanceof Conta) {
                custo += cont.getValorAPagar(diaPagto, mesPagto);
            }
        }
        return custo;
    }

    public double custoTotal(int diaPagto, int mesPagto) {
        double custoT = 0;
        for (Passivo cont : pagamentos) {
                custoT += cont.getValorAPagar(0,0);
        }
        return custoT;
    }
}
