package classes;

public interface Passivo {
    public static double SALARIO = 1320;
    public static double HORA = 65;

    public abstract double getValorAPagar(int diaPagto, int mesPagto);
    
    
}
