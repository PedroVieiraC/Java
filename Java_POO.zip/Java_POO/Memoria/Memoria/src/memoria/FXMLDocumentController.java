/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package memoria;
import memoria.logicaPVC.MemoriaLogicaPVC;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;

/**
 *
 * @author Marcela
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private ToggleButton b54;

    @FXML
    private ToggleButton b10;

    @FXML
    private ToggleButton b53;

    @FXML
    private ToggleButton b56;

    @FXML
    private ToggleButton b12;

    @FXML
    private ToggleButton b55;

    @FXML
    private ToggleButton b11;

    @FXML
    private ToggleButton b58;

    @FXML
    private ToggleButton b14;

    @FXML
    private ToggleButton b57;

    @FXML
    private ToggleButton b13;

    @FXML
    private ToggleButton b16;

    @FXML
    private ToggleButton b59;

    @FXML
    private ToggleButton b15;

    @FXML
    private ToggleButton b18;

    @FXML
    private ToggleButton b17;

    @FXML
    private ToggleButton b19;

    @FXML
    private ToggleButton b1;

    @FXML
    private ToggleButton b2;

    @FXML
    private ToggleButton b3;

    @FXML
    private ToggleButton b4;

    @FXML
    private ToggleButton b5;

    @FXML
    private ToggleButton b6;

    @FXML
    private ToggleButton b7;

    @FXML
    private ToggleButton b8;

    @FXML
    private ToggleButton b9;

    @FXML
    private ToggleButton b60;

    @FXML
    private ToggleButton b21;

    @FXML
    private ToggleButton b20;

    @FXML
    private ToggleButton b23;

    @FXML
    private ToggleButton b22;

    @FXML
    private ToggleButton b25;

    @FXML
    private ToggleButton b24;

    @FXML
    private ToggleButton b27;

    @FXML
    private ToggleButton b26;

    @FXML
    private ToggleButton b29;

    @FXML
    private ToggleButton b28;

    @FXML
    private Button Sair;

    @FXML
    private ToggleButton b30;

    @FXML
    private ToggleButton b32;

    @FXML
    private ToggleButton b31;

    @FXML
    private ToggleButton b34;

    @FXML
    private ToggleButton b33;

    @FXML
    private ToggleButton b36;

    @FXML
    private ToggleButton b35;

    @FXML
    private ToggleButton b38;

    @FXML
    private ToggleButton b37;

    @FXML
    private ToggleButton b39;

    @FXML
    private ToggleButton b41;

    @FXML
    private ToggleButton b40;

    @FXML
    private ToggleButton b43;

    @FXML
    private ToggleButton b42;

    @FXML
    private ToggleButton b45;

    @FXML
    private ToggleButton b44;

    @FXML
    private ToggleButton b47;

    @FXML
    private ToggleButton b46;

    @FXML
    private ToggleButton b49;

    @FXML
    private ToggleButton b48;

    @FXML
    private ToggleButton b50;

    @FXML
    private ToggleButton b52;

    @FXML
    private ToggleButton b51;

    @FXML
    private Button Novo;
    

    private ArrayList<ToggleButton> botoes = new ArrayList<ToggleButton>();

    @FXML
    private void handleButtonAction(ActionEvent event) {

        //botoes = new ArrayList<ToggleButton>;
        botoes.addAll(Arrays.asList(b1, b2, b3, b4, b5, b6, b7, b8, b9, b10,
                b11, b12, b13, b14, b15, b16, b17, b18, b19, b20,
                b21, b22, b23, b24, b25, b26, b27, b28, b29, b30,
                b31, b32, b33, b34, b35, b36, b37, b38, b39, b40,
                b41, b42, b43, b44, b45, b46, b47, b48, b49, b50,
                b51, b52, b53, b54, b55, b56, b57, b58, b59, b60));

        String face = ((Button) event.getSource()).getText();
        
        MemoriaLogicaPVC MemoriaLogicaPVC = new MemoriaLogicaPVC();
        
        int[] vetor = new int[60];
        
        MemoriaLogicaPVC.preencheVetorAleatorio(vetor);
            
        for(int i=0;i<vetor.length;i++){
                System.out.println(vetor[i]);
        }

        if (((Button) event.getSource()).getText().equals("Novo")) {

        }

        if (((Button) event.getSource()).getText().equals("Sair")) {
            System.exit(0);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
