Nome: Pedro Vieira Conceição

// Funçao do programa
O programa tem como intuito simular um sistema de banco símples;

//Informações importantes

Para rodar o programa é só executar a classe CentralBanco;

para cadastro, é necessário que os arquivos de dados estejam limpos;

pix é efetuado pelo cpf que cadastrou;

//futuras atualizações
gostaria de ter adicionado mais funções antes da entrega, entretanto não soube conciliar o tempo;

próximos adds serão pagar contas, sistema de classes e uso de arraylist pra melhor dev do arquivo;
