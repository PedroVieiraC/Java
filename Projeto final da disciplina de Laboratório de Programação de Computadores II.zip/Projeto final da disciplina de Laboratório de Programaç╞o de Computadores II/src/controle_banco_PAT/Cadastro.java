/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle_banco_PAT;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Cadastro extends Application {
       protected static Stage janela;
       
    /**
 * Método principal que inicia a aplicação.
 *
 * @param stage O palco principal da aplicação.
 */   
    public void start(Stage stage) {

        FXMLLoader fxmlLoader = new FXMLLoader(Cadastro.class.getResource("/visao_banco_PAT/FXMLCadastro.fxml"));
        Scene scene = null;    
        try {
            scene = new Scene(fxmlLoader.load());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        Cadastro.janela =stage;
        stage.setTitle("Cadastro");
        stage.setScene(scene);

        stage.show();
                
        }

}
