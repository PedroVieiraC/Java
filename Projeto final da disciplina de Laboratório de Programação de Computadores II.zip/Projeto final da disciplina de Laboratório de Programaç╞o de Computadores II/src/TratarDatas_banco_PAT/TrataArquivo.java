/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TratarDatas_banco_PAT;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import Exceptions_banco_PAT.Cliente_existenteexception;

public class TrataArquivo {
 
     public void escreverArquivoTexto(String caminhoArquivo, String cpf, String senha, int matricula) throws IOException {
        File arquivo = new File(caminhoArquivo);
        FileWriter escreverArquivo = new FileWriter(arquivo, true); // Usamos o segundo parâmetro como true para permitir a escrita no final do arquivo
        escreverArquivo.write(cpf + "*" + senha + "*" + matricula + "*");
        escreverArquivo.close();

    }
     
    public void escreverArquivoTextoDados(String caminhoArquivo, String nome) throws IOException {
        File arquivo = new File(caminhoArquivo);
        FileWriter escreverArquivo = new FileWriter(arquivo, true); // Usamos o segundo parâmetro como true para permitir a escrita no final do arquivo
        escreverArquivo.write(nome + "*" +"0" + "*");
        escreverArquivo.close();

    } 
    
     public void reescreverArquivoTexto(String ddl, String reescrita) throws IOException {
        File arquivo = new File(ddl);
        FileWriter escreverArquivo = new FileWriter(arquivo);
        escreverArquivo.write(reescrita);
        escreverArquivo.close();

    }
     
     public String lerArquivoTexto(String filePath) throws IOException {
        File arquivo = new File(filePath);
        FileReader fileReader = new FileReader(arquivo);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String linha;
        StringBuilder sb = new StringBuilder();
        while ((linha = bufferedReader.readLine()) != null) {
            sb.append(linha);
        }
        bufferedReader.close();
        return sb.toString();
    }
    
}
