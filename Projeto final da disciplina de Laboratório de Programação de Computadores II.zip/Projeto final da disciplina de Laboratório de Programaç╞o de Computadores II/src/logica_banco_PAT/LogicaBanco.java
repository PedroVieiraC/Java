package logica_banco_PAT;

import java.util.ArrayList;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;
import Exceptions_banco_PAT.*;
import TratarDatas_banco_PAT.TrataArquivo;
import java.util.Arrays;

public class LogicaBanco {

    //classes
    private TrataArquivo ta = new TrataArquivo();

    //strings comando
    //ddl = arquivo dados de login
    private String ddl = "./src/database_banco_PAT/ddl.txt";
    //db = dados bancários
    private String db = "./src/database_banco_PAT/idc.txt";
    //strings auxiliares p manipulacao
    private String dadosLogin = new String();
    private String dadosBancarios = new String();
    //gerador de matricula
    private int matricula;
    private String[] matriculaGen;
    private int rp;
    private String nome;

    //clientes
    private ArrayList<Clientes> clientes = new ArrayList<>();

    /**
     * Obtém o RP (Registro de Pessoa) do cliente logado.
     *
     * @return O RP do cliente logado.
     */
    public int getRp() {
        return rp;
    }

    /**
     * Obtém o nome do cliente logado.
     *
     * @return O nome do cliente logado.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Realiza o login de um cliente no banco PAT.
     *
     * @param cpf O CPF do cliente.
     * @param senha A senha do cliente.
     * @return O RP do cliente logado. Retorna -2 se a senha estiver errada e -1
     * se o CPF não for encontrado.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     * @throws Senha_erradaexception Exceção lançada se a senha estiver errada.
     */
    public int Login(String cpf, String senha) throws IOException, Senha_erradaexception {
        LerBancoDadosLogin();
        String[] partes = dadosLogin.split("\\*");
        int matcliente;

        //return -2 = senha não encontrada
        //return -1 = cpf não encontrado
        for (int i = 0; i < partes.length; i++) {
            //login correto 
            if (partes[i].equals(cpf) && partes[i + 1].equals(senha)) {
                matcliente = Integer.parseInt(partes[i + 2]);
                rp = matcliente;
                return matcliente;
            } //senha errada 
            else if (partes[i].equals(cpf) && !(partes[i + 1].equals(senha))) {
                return -2;
            }
        }
        return (-1);
    }

    /**
     * Realiza o cadastro de um cliente no banco PAT.
     *
     * @param nome O nome do cliente.
     * @param cpf O CPF do cliente.
     * @param senha A senha do cliente.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     * @throws Cliente_existenteexception Exceção lançada se o cliente já
     * estiver cadastrado.
     */
    public void cadastrarCliente(String nome, String cpf, String senha) throws IOException, Cliente_existenteexception {
        try {
            escreverCadastro(ddl, nome, cpf, senha);
            //escreverDados(db,cpf, nome);
        } catch (Cliente_existenteexception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro");
            alert.setHeaderText(null);
            alert.setContentText("Cliente já cadastrado!");
            alert.showAndWait();
        } catch (IOException ex) {
            Logger.getLogger(LogicaBanco.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //tratamento de arquivos tem que passar pra classe tratar arquivos
    public void LerBancoDadosLogin() throws IOException {
        try {
            preencheDadosLogin(ddl);
        } catch (IOException e) {
            System.out.println("Banco de dados inexistente: ");
        }

    }

    /**
     * Escreve os dados de cadastro de um cliente no arquivo especificado.
     *
     * @param ddl O caminho do arquivo de dados de login.
     * @param nome O nome do cliente.
     * @param cpf O CPF do cliente.
     * @param senha A senha do cliente.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     * @throws Cliente_existenteexception Exceção lançada se o cliente já
     * estiver cadastrado.
     */
    public void escreverCadastro(String ddl, String nome, String cpf, String senha) throws IOException, Cliente_existenteexception {
        if (existeCliente(cpf) == false) {
            String[] matriculaGen = dadosLogin.split("\\*");
            matricula = (matriculaGen.length / 3);
            ta.escreverArquivoTexto(ddl, cpf, senha, matricula);
            ta.escreverArquivoTextoDados(db, nome);
            preencheDadosLogin(ddl);
            preencheDadosBancarios(db);
        } else {
            throw new Cliente_existenteexception("Cliente já cadastrado");
        }
    }

    /**
     * Verifica se um cliente com o CPF especificado já está cadastrado.
     *
     * @param cpf O CPF do cliente.
     * @return true se o cliente já está cadastrado, false caso contrário.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public boolean existeCliente(String cpf) throws IOException {
        LerBancoDadosLogin();
        String[] partes = dadosLogin.split("\\*");

        for (String parte : partes) {
            //login correto
            if (parte.equals(cpf)) {
                return true;
            }
        }

        return false;
        //return true = cliente já cadastrado
        //return false = cliente nao cadastrado

    }

    /**
     * Preenche os dados de login a partir do arquivo especificado.
     *
     * @param filePath O caminho do arquivo de dados de login.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public void preencheDadosLogin(String filePath) throws IOException {
        dadosLogin = ta.lerArquivoTexto(filePath);
    }

    /**
     * Preenche os dados bancários a partir do arquivo especificado.
     *
     * @param filePath O caminho do arquivo de dados bancários.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
//tratamento de informações de transferência, deposito, pagamentos...
    public void preencheDadosBancarios(String filePath) throws IOException {
        dadosBancarios = ta.lerArquivoTexto(filePath);
    }

    /**
     * Preenche a lista de clientes a partir dos dados bancários.
     *
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public void preencheClientes() throws IOException {
        preencheDadosBancarios(db);
        String[] partes = dadosBancarios.split("\\*");
    }

    public void nome() throws IOException {
        preencheDadosBancarios(db);
        String[] partes = dadosBancarios.split("\\*");
        int a = (rp * 2);
        nome = partes[a];

    }

    /**
     * Obtém o saldo do cliente logado.
     *
     * @return O saldo do cliente logado.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public String mostrarSaldo() throws IOException {
        preencheDadosBancarios(db);
        preencheDadosLogin(ddl);
        String[] partes = dadosBancarios.split("\\*");
        int a = (rp * 2) + 1;
        return partes[a];

    }

    /**
     * Obtém o RP (Registro de Pessoa) de um cliente a partir do CPF.
     *
     *
     * @return O RP do cliente.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public int clienteTransferir(String cpf) throws IOException {
        LerBancoDadosLogin();
        String[] partes = dadosLogin.split("\\*");
        for (int i = 0; i < partes.length; i++) {
            if (partes[i].equals(cpf)) {
                return (Integer.parseInt(partes[i + 2]));
            }
        }
        return 0;
    }

    /**
     * Realiza uma transferência PIX entre clientes.
     *
     * @param referencia O RP do cliente que está realizando a transferência.
     * @param passagem O RP do cliente que está recebendo a transferência.
     * @param valortransferido O valor a ser transferido.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public void pix(int referencia, int passagem, float valortransferido) throws IOException {
        preencheDadosBancarios(db);
        String[] partes = dadosBancarios.split("\\*");

        float saldo1, saldo2, saldof1, saldof2;

        //operação entre contas
        saldo1 = Float.parseFloat(partes[(referencia * 2) + 1]);
        saldo2 = valortransferido;
        saldof1 = saldo1 - valortransferido;
        saldof2 = Float.parseFloat(partes[(passagem * 2) + 1]) + saldo2;

        //alteracao no bd
        partes[(referencia * 2) + 1] = String.valueOf(saldof1);
        partes[(passagem * 2 + 1)] = String.valueOf(saldof2);

        String reescrita = new String();

        for (int i = 0; i < partes.length; i++) {
            reescrita += partes[i];
            reescrita += "*";
        }
        ta.reescreverArquivoTexto(db, reescrita);
    }

    /**
     * Realiza um depósito na conta do cliente.
     *
     * @param referencia O RP do cliente que está realizando o depósito.
     * @param valortransferido O valor a ser depositado.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    public void deposito(int referencia, float valortransferido) throws IOException {
        preencheDadosBancarios(db);
        String[] partes = dadosBancarios.split("\\*");

        float saldo1, saldof1;

        //operação entre contas
        saldo1 = Float.parseFloat(partes[(referencia * 2) + 1]);
        saldof1 = saldo1 + valortransferido;

        //alteracao no bd
        partes[(referencia * 2) + 1] = String.valueOf(saldof1);

        String reescrita = new String();
        for (int i = 0; i < partes.length; i++) {
            reescrita += partes[i];
            reescrita += "*";
        }

        ta.reescreverArquivoTexto(db, reescrita);
    }

}
