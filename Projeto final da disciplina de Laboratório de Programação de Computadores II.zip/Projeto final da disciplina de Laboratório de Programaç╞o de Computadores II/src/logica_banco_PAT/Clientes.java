package logica_banco_PAT;

public class Clientes {
    private String nome;
    private float dinheiro;
    private int matricula;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getDinheiro() {
        return dinheiro;
    }

    public void setDinheiro(float dinheiro) {
        this.dinheiro = dinheiro;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public Clientes(String nome, float dinheiro,int matricula) {
        this.nome = nome;
        this.dinheiro = dinheiro;
        this.matricula = matricula;
    }    
    
    
    @Override
    public String toString() {
        return "Nome: " + nome + ", Dinheiro: " + dinheiro;
    }
    
}
