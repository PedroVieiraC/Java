/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package logica_banco_PAT;

import Exceptions_banco_PAT.Cliente_existenteexception;
import controle_banco_PAT.Centralbanco;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FXMLCadastroController {

    private LogicaBanco lgb = new LogicaBanco();

    @FXML
    private Button bt_voltar;

    @FXML
    private TextField txt_senha;

    @FXML
    private TextField txt_nome;

    @FXML
    private TextField txt_cpf;

    @FXML
    private Button bt_cadastro;

    /**
     * Método chamado quando o botão "Voltar" é clicado.
     *
     * @param event O evento de clique do botão.
     */
    @FXML
    public void voltar(ActionEvent event) {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    /**
     * Método chamado quando o botão "Cadastrar" é clicado.
     *
     * @param event O evento de clique do botão.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     * @throws Cliente_existenteexception Exceção lançada caso o cliente já
     * exista.
     */
    public void cadastrar(ActionEvent event) throws IOException, Cliente_existenteexception {
        try {
            Centralbanco.logicabanco.cadastrarCliente(txt_nome.getText(), txt_cpf.getText(), txt_senha.getText());
            limpaTela();
        } catch (Cliente_existenteexception e) {
        }

    }

    /**
     * Limpa os campos de entrada de texto da tela.
     */
    private void limpaTela() {
        this.txt_cpf.setDisable(false);
        this.txt_senha.setDisable(false);

    }

}
