/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package logica_banco_PAT;

import controle_banco_PAT.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Exceptions_banco_PAT.*;

public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField txt_nome;

    @FXML
    private Button bt_sair;

    @FXML
    private Label label;

    @FXML
    private Button bt_entrar;

    @FXML
    private TextField txt_senha;

    @FXML
    private TextField txt_cpf;

    @FXML
    private Button bt_cadastro;

    /**
     * Método que lança uma exceção Senha_erradaexception.
     *
     * @throws Senha_erradaexception Exceção lançada quando a senha está
     * incorreta.
     */
    public void lancasenhaex() throws Senha_erradaexception {

        throw new Senha_erradaexception("Senha errada");

    }

    /**
     * Método que lança uma exceção Cliente_existenteexception.
     *
     * @throws Cliente_existenteexception Exceção lançada quando o cliente já
     * existe.
     */
    public void lancaclienteex() throws Cliente_existenteexception {

        throw new Cliente_existenteexception("Cliente já existe");

    }

    /**
     * Método que lança uma exceção Cliente_NEexception.
     *
     * @throws Cliente_NEexception Exceção lançada quando o cliente não está
     * cadastrado.
     */
    public void lancacliente_NE() throws Cliente_NEexception {

        throw new Cliente_NEexception("Cliente não cadastrado");

    }

    /**
     * Método chamado quando o botão "Entrar" é clicado.
     *
     * @param Entrar O evento de clique do botão.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     * @throws Senha_erradaexception Exceção lançada quando a senha está
     * incorreta.
     * @throws Cliente_NEexception Exceção lançada quando o cliente não está
     * cadastrado.
     */
    @FXML
    public void login(ActionEvent Entrar) throws IOException, Senha_erradaexception, Cliente_NEexception {

        int cliente;
        cliente = Centralbanco.logicabanco.Login(txt_cpf.getText(), txt_senha.getText());
        try {
            if (cliente == -1) {
                lancacliente_NE();
                System.out.println("cliente nao encontrado");
            }
            if (cliente == -2) {
                lancasenhaex();
            } else if (cliente >= 0) {
                System.out.println("cliente: " + Centralbanco.logicabanco.Login(txt_cpf.getText(), txt_senha.getText()));
                Telainicio janela = new Telainicio();
                janela.start(new Stage());
            }

        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Senha_erradaexception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro");
            alert.setHeaderText(null);
            alert.setContentText("Senha errada!");
            alert.showAndWait();
        } catch (Cliente_NEexception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro");
            alert.setHeaderText(null);
            alert.setContentText("Cliente não cadastrado");
            alert.showAndWait();
        }
    }

    /**
     * Método chamado quando o botão "Sair" é clicado.
     *
     * @param sair O evento de clique do botão.
     */
    @FXML
    public void sair(ActionEvent sair) {
        Platform.exit();
    }

    /**
     * Método chamado quando o botão "Cadastro" é clicado.
     *
     * @param event O evento de clique do botão.
     * @throws Cliente_existenteexception Exceção lançada quando o cliente já
     * existe.
     */
    @FXML
    void cadastrar(ActionEvent event) throws Cliente_existenteexception {
        Cadastro janela = new Cadastro();
        janela.start(new Stage());

    }

    /**
     * Método que limpa os campos de entrada de texto da tela.
     */
    private void limpaTela() {
        this.txt_cpf.setDisable(false);
        this.txt_senha.setDisable(false);

    }

    /**
     * Método inicializador da classe.
     *
     * @param url A URL do local do arquivo FXML.
     *  O ResourceBundle usado para localizar os recursos.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
