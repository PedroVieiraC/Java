/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package logica_banco_PAT;

import controle_banco_PAT.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;

public class FXMLTelainicioController implements Initializable {

    @FXML
    private Button bt_pix;

    @FXML
    private Label lbl_nome;

    @FXML
    private Button bt_boleto;

    @FXML
    private Button bt_deposito;

    @FXML
    private Button bt_voltar;

    @FXML
    private ToggleButton tb_saldo;

    /**
     * Método chamado quando o botão "mostrar saldo" é acionado.
     *
     * @param event O evento de clique do botão.
     * @throws IOException Exceção lançada em caso de erro de E/S.
     */
    @FXML
    public void mostrarsaldo(ActionEvent event) throws IOException {
        Centralbanco.logicabanco.preencheClientes();

        if (tb_saldo.isSelected()) {
            tb_saldo.setText(Centralbanco.logicabanco.mostrarSaldo());
        } else {
            tb_saldo.setText("mostrar saldo");
        }

    }

    /**
     * Método chamado quando o botão "PIX" é acionado.
     *
     * @param event O evento de clique do botão.
     */
    @FXML
    public void pix(ActionEvent event) {
        Pix janela = new Pix();
        janela.start(new Stage());
    }

    /**
     * Método chamado quando o botão "Depósito" é acionado.
     *
     * @param event O evento de clique do botão.
     */
    @FXML
    public void deposito(ActionEvent event) {
        Deposito janela = new Deposito();
        janela.start(new Stage());

    }

    @FXML
    public void voltar(ActionEvent event) {
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Centralbanco.logicabanco.nome();
            lbl_nome.setText(Centralbanco.logicabanco.getNome());
        } catch (IOException ex) {
            Logger.getLogger(FXMLTelainicioController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
