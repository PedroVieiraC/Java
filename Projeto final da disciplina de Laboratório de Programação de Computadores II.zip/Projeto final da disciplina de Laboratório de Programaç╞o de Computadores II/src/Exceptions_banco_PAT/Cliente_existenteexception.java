package Exceptions_banco_PAT;

public class Cliente_existenteexception extends Exception {

    public Cliente_existenteexception() {
        super();
    }

    public Cliente_existenteexception(String mensagem) {
        super(mensagem);
    }

    public Cliente_existenteexception(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }

    public Cliente_existenteexception(Throwable causa) {
        super(causa);
    }

}
