package Exceptions_banco_PAT;

public class Cliente_NEexception extends Exception {

    public Cliente_NEexception() {
        super();
    }

    public Cliente_NEexception(String mensagem) {
        super(mensagem);
    }

    public Cliente_NEexception(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }

    public Cliente_NEexception(Throwable causa) {
        super(causa);
    }

}
