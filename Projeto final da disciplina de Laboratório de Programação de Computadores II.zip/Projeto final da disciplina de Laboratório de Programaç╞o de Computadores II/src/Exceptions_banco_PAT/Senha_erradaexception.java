package Exceptions_banco_PAT;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Senha_erradaexception extends Exception {

    public Senha_erradaexception() {
        super();
    }

    public Senha_erradaexception(String mensagem) {
        super(mensagem);
    }

    public Senha_erradaexception(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }

    public Senha_erradaexception(Throwable causa) {
        super(causa);
    }

}
